import re

def validar_nom(nom):
    # Nom: només lletres (incloent accents) i espais, mínim 2 caràcters.
    return re.match(r'^[A-Za-zÀ-ú\s]{2,}$', nom)
# Carregar els participants des d'un fitxer
def carregar_participants_de_fitxer(fitxer):
    try:
        with open(fitxer, 'r') as f:
            content = f.read().strip()
            if not content:
                return []
            return [p.strip() for p in content.split(",") if p.strip()]
    except FileNotFoundError:
        return []
# Guardar participants

def desar_participants_a_fitxer(participants, fitxer):
    with open(fitxer, 'w') as f:
        # Escriu els participants separats per comes en una sola línia
        f.write(", ".join(participants))

def afegir_participant(nom, fitxer='participants.txt'):
    participants = carregar_participants_de_fitxer(fitxer)
    if nom in participants:
        return False
        # Si el participant ja existeix, retorna fals
    participants.append(nom)
    desar_participants_a_fitxer(participants, fitxer)
    return True
# Eliminar participant
def eliminar_participant(nom, fitxer='participants.txt'):
    participants = carregar_participants_de_fitxer(fitxer)
    if nom in participants:
        participants.remove(nom)
        desar_participants_a_fitxer(participants, fitxer)
        return True
    return False