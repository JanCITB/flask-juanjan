def actualitzar_puntuacions(puntuacions, guanyador):
    if guanyador in puntuacions: # Si el guanyador ja existeix, suma el punt
        puntuacions[guanyador] += 1
    else:
        puntuacions[guanyador] = 1# Si no existeix, afegim un punt

def calcular_ranquing(puntuacions):
    return sorted(puntuacions.items(), key=lambda x: x[1], reverse=True)
# Carregar puntuacions
def carregar_puntuacions(fitxer):
    try:
        with open(fitxer, 'r') as f:
            lines = f.readlines() # Llegir tot el fitxer
        resultats = {}
        for linies in lines:
            if ':' in linies:
                parts = linies.strip().split(':')
                name = parts[0].strip()# Nom del participant
                try:
                    score = int(parts[1].strip())# Punts
                except ValueError:
                    score = 0
                resultats[name] = score# Guardem el resultat
        return resultats
    except FileNotFoundError:# Si no existeix el fitxer, retornem un diccionari buit
        return {}